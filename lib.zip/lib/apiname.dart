class APIENDPOINTNAME {
  static String HOME = "http://68.183.93.42:8999/api/";
  // static String HOME = "https://philebackendapp.onrender.com/api/";
  // static String HOME = "http://192.168.0.103:8000/api/";
  static String CREATEUSER = HOME + "adduser/";
  static String LOGINUSER = HOME + "verifyuser/";
  static String GENERATEOTP = HOME + "generateotp/";
  static String VERIFYOTP = HOME + "verifyotp/";
  static String STOREDETAILS = HOME + "getregisteredstores/";
  static String GETORDERS = HOME + "getuserorderdetail/";
  static String GETAVAILTIME = HOME + "gettimesofday/";
  static String UPDATEUSERPASS = HOME + "updateruserpass/";
  static String UPDATEUSERPHONE = HOME + "updateuserphonenum/";
  static String UPDATEUSEREMAIL = HOME + "updateuseremail/";
  static String ORDERSERVICE = HOME + "addorder/";
  static String FORGOTPASSCHECKER = HOME + "forgotpasschecker/";
  static String FORGOTPASSCHANGE = HOME + "forgotpasschange/";
  static String RAISEQUERY = HOME + "raisequery/";
}
